/////////////////////
//  redis_db.h
/////////////////////
#ifndef __REDIS_DB_H_INCLUDE__
#define __REDIS_DB_H_INCLUDE__

#ifdef __cplusplus
extern "C"
{
#endif

typedef enum DB_Op {	  //Function return operation enum.
    OP_STR_GET = 0,    //Redis GET operation
    OP_STR_SET = 1,    //Redis Set operation.
    OP_STR_DEL = 2,    //Redis Del operation.
    OP_STR_DEL_DELAY = 3,    //Redis Del operation.
    OP_STR_HSET = 4,    //Redis hash set operation.
    OP_STR_HDEL = 5,
}DB_OP_E;

typedef struct DB_Command_List
{
	DB_OP_E dbOp;
	char  *key;
	char  *data;
	int  data_length;
	struct DB_Command_List *next;
} DB_Command_List;

enum DB_Flag {  // For 'flag' field.
	DB_FLAG_NONE = 0,    //No consume of message.
	DB_FLAG_FCR = 1,     //Only Slave FCR consume message, Syncer drop message.
	DB_FLAG_SYNCER = 2,  //Only Syncer consume message, Slave FCR drop message.
	DB_FLAG_All = 3,     //Slave FCR & Syncer Both Consume Message.
};

typedef enum DB_ErrNo {      //Function return value definition.
	DB_ERRNO_OK = 0,             //OK
	DB_ERRNO_REPLY_ERROR = 1,    //Redis reply error.
	DB_ERRNO_TIMEOUT     = 2,     //Redis timeout.
	DB_ERRNO_CONNECT_CLOSE = 3,  //Redis connect close.
	DB_ERRNO_IO			   = 4,    //Redis io error.
	DB_ERRNO_OTHER = 5,      //Redis other error.
	DB_ERRNO_NOEXIST = 6,      //Redis data no exist.
	DB_ERRNO_END = 7,         //Redis lst data end.
	DB_ERRNO_WRITE_FAIL = 8,         //Redis write data Fail.
	DB_ERRNO_RELEASE = 9,         //Redis handle free.
}DB_ERRNO_E;

typedef enum DB_Type {	  //Function return operation enum.
    REDIS_DEFAULT_DB  = 0,    //default DB
    REDIS_CONFIG_DB  = 1,    //Redis config DB
    REDIS_STATE_DB   = 2,    //Redis state DB.
    REDIS_COUNTER_DB = 3,    //Redis counter DB.
    REDIS_APP_DB     = 4,    //Redis app DB.
    REDIS_DB_TYPE_MAX,
}DB_TYPE_E;

typedef struct DB_Key_List {  // For DB_Get_Key
	char *key;
	struct DB_Key_List *next;
}DB_Key_List;

typedef struct DB_List_Data
{
	DB_OP_E dbOp;
	char  *data;
	int  data_length;
	struct DB_List_Data *next;
} DB_List_Data;

typedef struct DB_KeyValue_List {  // For DB_Get_KeyAndValue
	char *key;
	char  *data;
	int  data_length;
	struct DB_KeyValue_List *next;
}DB_KeyValue_List;

typedef struct DB_FieldValue_List {  // For DB_Get_KeyAndValue
	char *key;
	char *field;
	char *value;
	int  key_length;
	int  field_length;
	int  value_length;
	struct DB_FieldValue_List *next;
}DB_FieldValue_List;

typedef struct Sentinel_Info {
	char				ip_addr[128];
	unsigned int		port;
}SENTINEL_INFO_S;

#define REDIS_DB_INFO_STR_MAX_LEN 120

typedef struct Redis_Info{
	SENTINEL_INFO_S		sentinelInfo;
	int					db;
}REDIS_INFO_S;

typedef struct DB_KeyFieldValue_List {  // For DB_Get_KeyAndValue
    int fieldcnt;
    char **field;
    char **value;
	struct DB_KeyFieldValue_List *next;
}DB_KeyFieldValue_List;

struct redis_user_ext {
	int (*redis_Connect)(REDIS_INFO_S *pstRediDbInfo, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);
	void (*redis_DisConnect)(char *dbErrMsg, int msglen);
	int (*redis_Db_WriteStr)(char *key, const void *data, const int data_len, int flag, char *dbErrMsg, int msglen);

	int (*redis_Db_GetStr)(char *key, void *data, int *data_len, char *dbErrMsg, int msglen);

	int (*redis_Db_DeleteStr)(char *key, int flag, char *dbErrMsg, int msglen);

	int (*redis_Db_WriteLst)(char *key, const void *data, const int data_len, int flag, char *dbErrMsg, int msglen);

	DB_List_Data *(*redis_Db_GetLst)(char *key, int flag, char *dbErrMsg, int msglen);

	void (*redis_Set_Timeout)(int timeout);

	DB_Key_List *(*redis_Db_GetKey)(char *key_prefix, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);

	int (*redis_Db_DropAll)(char *dbErrMsg, int msglen);

	int (*redis_Db_WriteStrBatch)(DB_Command_List *keyLst, int flag, char *dbErrMsg, int msglen);
	DB_KeyValue_List *(*redis_Db_GetKeyAndValue)(char *key_prefix, int count, int *cursor, char *dbErrMsg, int msglen);
	DB_KeyValue_List *(*redis_Db_GetKeyAndValueNoCursor)(char *key_prefix, char *dbErrMsg, int msglen);
	void (*redis_Set_DelDelayTime)(int delaytime);
	int (*redis_Db_Save)(char *dbErrMsg, int msglen);
	int (*redis_SubscriberMsg)(char *key, int (*func)(char *, char *));
	int (*redis_PublishMsg)(char *key, char *msg, DB_TYPE_E enDbType);
	int (*redis_PSubscriberMsg)(char *key, char *dbErrMsg, int (*func)(char *, char *, int, DB_OP_E));
	void (*redis_SubscriberDisConnect)(char *dbErrMsg, int msglen);
	void (*redis_ConfigChange)(void);
	DB_List_Data *(*redis_Db_GetLstByNum)(char *key, int cnt, int flag, int *ret, char *dbErrMsg, int msglen);
	int (*redis_Db_DelLstByNum)(char *key, int cnt, int flag, char *dbErrMsg, int msglen);
	int (*redis_Db_WriteLstBatch)(char *key, DB_List_Data *pstDataLst, int flag, char *dbErrMsg, int msglen);
	int (*redis_Db_DropSingleDB)(char *dbErrMsg, int msglen);
	int (*redis_Db_DelAll)(char *key, char *dbErrMsg, int msglen);
	int (*redis_Db_DispConnectInfo)(char *dbErrMsg, int msglen);
	int (*redis_PSubscriberMsgMultiKey)(DB_Key_List *keylst, char *dbErrMsg, int (*func)(char *, char *, int, DB_OP_E));
	int (*redis_Db_DelKeyLst)(DB_Key_List *pstKeylist, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);
	int (*redis_Db_SetKeyAndFValue)(char *key, DB_FieldValue_List *pstDataLst, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);
	int (*redis_Db_WriteFVBatch)(DB_FieldValue_List *keyLst, DB_OP_E dbOp, char *dbErrMsg, int msglen);
	int (*redis_Db_LpushBulk)(char *key, char *data, int dataLen, unsigned int rcount, unsigned int op, char *dbErrMsg, int msglen);
	int (*redis_Db_SetSadd)(char *key, char *member, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);
    void (*redis_Db_HGetKeyAndValueNoCursor)(char *key_prefix, char *field, char* result, int resultlen, char *dbErrMsg, int msglen, int *errNo, DB_TYPE_E enDbType);
    DB_KeyFieldValue_List *(*redis_Db_HGetAllKeyAndValueNoCursor)(char *key_prefix, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);
};


int Redis_Connect(REDIS_INFO_S *pstRediDbInfo, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);

int Redis_Db_WriteStr(char *key, const void *data, const int data_len, int flag, char *dbErrMsg, int msglen);

int Redis_Db_GetStr(char *key, void *data, int *data_len, char *dbErrMsg, int msglen);

int Redis_Db_DeleteStr(char *key, int flag, char *dbErrMsg, int msglen);

int Redis_Db_WriteLst(char *key, const void *data, const int data_len, int flag, char *dbErrMsg, int msglen);

DB_List_Data *Redis_Db_GetLst(char *key, int flag, char *dbErrMsg, int msglen);

void Redis_Set_Timeout(int timeout);

DB_Key_List *Redis_Db_GetKey(char *key_prefix, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);

int Redis_Db_DropAll(char *dbErrMsg, int msglen);

int Redis_Db_WriteStrBatch(DB_Command_List *keyLst, int flag, char *dbErrMsg, int msglen);

void Redis_DisConnect(char *dbErrMsg, int msglen);

DB_KeyValue_List *Redis_Db_GetKeyAndValue(char *key_prefix, int count, int *cursor, char *dbErrMsg, int msglen);
DB_KeyValue_List *Redis_Db_GetKeyAndValueNoCursor(char *key_prefix, char *dbErrMsg, int msglen);
void Redis_Db_HGetKeyAndValueNoCursor(char *key_prefix, char *field, char* result, int resultlen, char *dbErrMsg, int msglen, int *errNo, DB_TYPE_E enDbType);
DB_KeyFieldValue_List *Redis_Db_HGetAllKeyAndValueNoCursor(char *key_prefix, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);

void Redis_Set_DelDelayTime(int delaytime);

int Redis_Db_Save(char *dbErrMsg, int msglen);

int Redis_SubscriberMsg(char *key, int (*func)(char *, char *));
int Redis_PublishMsg(char *key, char *msg);
int Redis_PSubscriberMsg(char *key, char *dbErrMsg, int (*func)(char *, char *, int, DB_OP_E));
void Redis_SubscriberDisConnect(char *dbErrMsg, int msglen);
void Redis_ConfigChange(void);
DB_List_Data * Redis_Db_GetLstByNum(char *key, int cnt, int flag, int *ret, char *dbErrMsg, int msglen);
int Redis_Db_DelLstByNum(char *key, int cnt, int flag, char *dbErrMsg, int msglen);
int Redis_Db_WriteLstBatch(char *key, DB_List_Data *pstDataLst, int flag, char *dbErrMsg, int msglen);
int Redis_Db_DropSingleDB(char *dbErrMsg, int msglen);
int Redis_Db_DelAll(char *key, char *dbErrMsg, int msglen);
int Redis_Db_DispConnectInfo(char *dbErrMsg, int msglen);
int Redis_PSubscriberMsgMultiKey(DB_Key_List *keylst, char *dbErrMsg, int (*func)(char *, char *, int, DB_OP_E));
int Redis_Db_DelKeyLst(DB_Key_List *pstKeylist, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);
int Redis_Db_SetKeyAndFValue(char *key, DB_FieldValue_List *pstDataLst, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);
int Redis_Db_WriteFVBatch(DB_FieldValue_List *keyLst, DB_OP_E dbOp, char *dbErrMsg, int msglen);
int Redis_Db_LpushBulk(char *key, const void *data, const int data_len, unsigned int rcount, unsigned int op, char *dbErrMsg, int msglen);
int Redis_Db_SetSadd(char *key, char *member, char *dbErrMsg, int msglen, DB_TYPE_E enDbType);
int Redis_PublishMsgForce(char *key, char *msg, DB_TYPE_E enDbType);

#ifdef __cplusplus
}
#endif



#endif  //  #define __REDIS_DB_H_INCLUDE__

