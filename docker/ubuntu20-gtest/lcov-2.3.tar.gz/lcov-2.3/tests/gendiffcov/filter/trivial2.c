int trivial(unsigned abc) {};
